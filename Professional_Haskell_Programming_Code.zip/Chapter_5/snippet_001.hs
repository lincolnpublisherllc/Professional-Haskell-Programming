  charge :: g -> Amount -> IO Result
