Calling C libraries from Haskell (foreign import ccall).
