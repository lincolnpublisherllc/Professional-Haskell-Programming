data Job = Job { jobId :: JobId, jobPayload :: Payload }
