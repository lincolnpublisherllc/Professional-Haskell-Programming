Overview of enabling extensions ({-# LANGUAGE ... #-}).
